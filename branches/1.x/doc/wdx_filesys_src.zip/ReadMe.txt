Filesys sample plugin:

It does the same as the (int) built-in content plugin

Author: Christian Ghisler
Licence: This plugin is in the public domain, you may use
this sample code for your own plugins