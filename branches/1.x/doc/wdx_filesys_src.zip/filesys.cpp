// filesys.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "contentplug.h"

#define _detectstring ""

#define fieldcount 19
char* fieldnames[fieldcount]={
	"name","size","creationdate","creationtime",
	"writedate","writetime","accessdate","accesstime",
	"attributes",
	"archive","read only","hidden","system",
	"compressed","encrypted","sparse",
	"versionstring","versionnr","file type"};

int fieldtypes[fieldcount]={
		ft_string,ft_numeric_64,ft_date,ft_time,
		ft_date,ft_time,ft_date,ft_time,
		ft_numeric_32,
		ft_boolean,ft_boolean,ft_boolean,ft_boolean,
		ft_boolean,ft_boolean,ft_boolean,
		ft_string,ft_numeric_floating,
		ft_multiplechoice};

char* fieldunits_and_multiplechoicestrings[fieldcount]={
		"","bytes|kbytes|Mbytes|Gbytes","","",
		"","","","",
		"",
		"","","","",
		"","","",
		"","","file|folder|reparse point"};
	
char* multiplechoicevalues[3]={
	"file","folder","reparse point"
};

BOOL GetValueAborted=false;


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

char* strlcpy(char* p,const char* p2,int maxlen)
{
    if ((int)strlen(p2)>=maxlen) {
        strncpy(p,p2,maxlen);
        p[maxlen]=0;
    } else
        strcpy(p,p2);
    return p;
}

int __stdcall ContentGetDetectString(char* DetectString,int maxlen)
{
	strlcpy(DetectString,_detectstring,maxlen);
	return 0;
}

int __stdcall ContentGetSupportedField(int FieldIndex,char* FieldName,char* Units,int maxlen)
{
	if (FieldIndex<0 || FieldIndex>=fieldcount)
		return ft_nomorefields;
	strlcpy(FieldName,fieldnames[FieldIndex],maxlen-1);
	strlcpy(Units,fieldunits_and_multiplechoicestrings[FieldIndex],maxlen-1);
	return fieldtypes[FieldIndex];
}

int __stdcall ContentGetValue(char* FileName,int FieldIndex,int UnitIndex,void* FieldValue,int maxlen,int flags)
{
	WIN32_FIND_DATA fd;
	FILETIME lt;
	SYSTEMTIME st;
	HANDLE fh;
	DWORD handle;
	DWORD dwSize;
	__int64 filesize;
	GetValueAborted=false;

	if (flags & CONTENT_DELAYIFSLOW) {
		if (FieldIndex==16)
			return ft_delayed;
		if (FieldIndex==17)
			return ft_ondemand;
	}

	fh=FindFirstFile(FileName,&fd);
	if (fh!=INVALID_HANDLE_VALUE) {
		FindClose(fh);
		switch (FieldIndex) {
		case 0:  //	"name"
			strlcpy((char*)FieldValue,fd.cFileName,maxlen-1);
			break;
		case 1:  // "size"
			filesize=fd.nFileSizeHigh;
			filesize=(filesize<<32) + fd.nFileSizeLow;
			switch (UnitIndex) {
			case 1:
				filesize/=1024;
				break;
			case 2:
				filesize/=(1024*1024);
				break;
			case 3:
				filesize/=(1024*1024*1024);
				break;
			}
			*(__int64*)FieldValue=filesize;
			break;
		case 2:  // "creationdate"
			FileTimeToLocalFileTime(&fd.ftCreationTime,&lt);
			FileTimeToSystemTime(&lt,&st);
			((pdateformat)FieldValue)->wYear=st.wYear;
			((pdateformat)FieldValue)->wMonth=st.wMonth;
			((pdateformat)FieldValue)->wDay=st.wDay;
			break;
		case 3:  // "creationtime",
			FileTimeToLocalFileTime(&fd.ftCreationTime,&lt);
			FileTimeToSystemTime(&lt,&st);
			((ptimeformat)FieldValue)->wHour=st.wHour;
			((ptimeformat)FieldValue)->wMinute=st.wMinute;
			((ptimeformat)FieldValue)->wSecond=st.wSecond;
			break;
		case 4:  // "writedate"
			FileTimeToLocalFileTime(&fd.ftLastWriteTime,&lt);
			FileTimeToSystemTime(&lt,&st);
			((pdateformat)FieldValue)->wYear=st.wYear;
			((pdateformat)FieldValue)->wMonth=st.wMonth;
			((pdateformat)FieldValue)->wDay=st.wDay;
			break;
		case 5:  // "writetime"
			FileTimeToLocalFileTime(&fd.ftLastWriteTime,&lt);
			FileTimeToSystemTime(&lt,&st);
			((ptimeformat)FieldValue)->wHour=st.wHour;
			((ptimeformat)FieldValue)->wMinute=st.wMinute;
			((ptimeformat)FieldValue)->wSecond=st.wSecond;
			break;
		case 6:  // "accessdate"
			FileTimeToLocalFileTime(&fd.ftLastAccessTime,&lt);
			FileTimeToSystemTime(&lt,&st);
			((pdateformat)FieldValue)->wYear=st.wYear;
			((pdateformat)FieldValue)->wMonth=st.wMonth;
			((pdateformat)FieldValue)->wDay=st.wDay;
			break;
		case 7:  // "accesstime",
			FileTimeToLocalFileTime(&fd.ftLastAccessTime,&lt);
			FileTimeToSystemTime(&lt,&st);
			((ptimeformat)FieldValue)->wHour=st.wHour;
			((ptimeformat)FieldValue)->wMinute=st.wMinute;
			((ptimeformat)FieldValue)->wSecond=st.wSecond;
			break;
		case 8:  // "attributes",
			*(int*)FieldValue=fd.dwFileAttributes;
			break;
		case 9: // "archive"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE;
			break;
		case 10: // "read only"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_READONLY;
			break;
		case 11: // "hidden"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN;
			break;
		case 12: // "system"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM;
			break;
		case 13: // "compressed"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_COMPRESSED;
			break;
		case 14: // "encrypted"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_ENCRYPTED;
			break;
		case 15: // "sparse"
			*(int*)FieldValue=fd.dwFileAttributes & FILE_ATTRIBUTE_SPARSE_FILE;
			break;
		case 16: // "versionstring"
		case 17: // "versionnr"
			dwSize = GetFileVersionInfoSize(FileName, &handle);
			if(dwSize) {
				VS_FIXEDFILEINFO *lpBuffer;
				void *pData=malloc(dwSize);
				GetFileVersionInfo(FileName, handle, dwSize, pData);
				if (VerQueryValue(pData, "\\", (void **)&lpBuffer, (unsigned int *)&dwSize)) {
					DWORD verhigh=lpBuffer->dwFileVersionMS >> 16;
					DWORD verlow=lpBuffer->dwFileVersionMS & 0xFFFF;
					if (FieldIndex==16) {
						char buf[128];
						DWORD verhigh2=lpBuffer->dwFileVersionLS >> 16;
						DWORD verlow2=lpBuffer->dwFileVersionLS & 0xFFFF;
						wsprintf(buf,"%d.%d.%d.%d",verhigh,verlow,verhigh2,verlow2);
						strlcpy((char*)FieldValue,buf,maxlen-1);
					} else {
						double version=verlow;
						while (version>=1)
							version/=10;
						version+=verhigh;
						*(double*)FieldValue=version;
						// make sure we have the correct DLL
					}
				} else {
					free(pData);
					return ft_fileerror;
				}
				free(pData);

/*				int i;                // used to simulate slow extraction
				for (i=0;i<50;i++) {
					Sleep(100);
					if (GetValueAborted)
						return ft_fieldempty;
				}
*/
			} else
				return ft_fileerror;
			break;
		case 18: // "file type"
			if ((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)==0)
				strlcpy((char*)FieldValue,multiplechoicevalues[0],maxlen-1);
			else if ((fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)==0)
				strlcpy((char*)FieldValue,multiplechoicevalues[1],maxlen-1);
			else
				strlcpy((char*)FieldValue,multiplechoicevalues[2],maxlen-1);
			break;
		default:
			return ft_nosuchfield;
		}
	} else
		return ft_fileerror;
	return fieldtypes[FieldIndex];  // very important!
}

void __stdcall ContentSetDefaultParams(ContentDefaultParamStruct* dps)
{

}

void __stdcall ContentStopGetValue	(char* FileName)
{
	GetValueAborted=true;
}
